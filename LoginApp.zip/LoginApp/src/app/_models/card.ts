export class Card {
    userId: string;
    cardNumber:number;
    cardType: string;
    firstName: string;
    lastName: string;
}