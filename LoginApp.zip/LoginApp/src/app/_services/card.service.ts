import {Injectable} from'@angular/core';
import{Http} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class CardService{
    constructor(private http:Http){
        console.log('CardService');
    }
    getPost(){
        return this.http.get('http://localhost:8080/src/app/mockService/cardDetails.json')
        .map(res =>res.json());
    }
    /*
    
    
    
    
    */
}