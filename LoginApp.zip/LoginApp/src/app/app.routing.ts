﻿import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';
import { AuthGuard } from './_guards/index';
import { CardServicesComponent } from './cardServices/index';
import { VerifyCardServicesComponent } from './cardServices/index';
import { ConfirmCardServicesComponent } from './cardServices/index';
const appRoutes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'cardServices', component: CardServicesComponent },
    { path: 'verifycardServices', component: VerifyCardServicesComponent },
     { path: 'confirmcardServices', component: ConfirmCardServicesComponent },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);