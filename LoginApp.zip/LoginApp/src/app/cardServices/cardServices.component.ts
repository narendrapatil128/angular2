import { Component, OnInit ,Pipe} from '@angular/core';

/*import { Router, ActivatedRoute } from '@angular/router';*/
import { Card } from '../_models/index';
import { User} from '../_models/index';
import { CardService } from '../_services/index';
import { MyFilterPipe } from '../filters/filter-pipe';
/*import { AlertService, AuthenticationService } from '../_services/index';*/

@Component({
    moduleId: module.id.toString(),
    
    templateUrl: 'cardServices.component.html',
    providers:[CardService],
     
})

export class CardServicesComponent /*implements OnInit*/ {
    currentUser: User;
    cards: Card[] = [];
    posts:Post[];
    /*selectedEntry:number;
    model: any = {};
    loading = false;
    returnUrl: string;*/
    constructor(private cardService: CardService
    /*private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService*/
    ){
      this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        
        this.cardService.getPost().subscribe(cards =>{
            console.log(cards);
            this.cards= cards;
        })
     /* ngOnInit() {
        // reset login status
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    } */

    
        /*login() {
        this.loading = true;
        this.authenticationService.login(this.model.username, this.model.password)
            .subscribe(
                data => {
                    this.router.navigate([this.returnUrl]);
                },
                error => {
                    this.alertService.error(error);
                    this.loading = false;
                });
    }*/
        /*blockedCard(cardnum) {
        this.selectedEntry = cardnum;
    }*/
  }

    /*constructor(private cardService: CardService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }*/

    /*ngOnInit() {
        this.loadAllUsers();
    }

    deleteUser(id: number) {
        this.cardService.delete(id).subscribe(() => { this.loadAllUsers() });
    }*/

    /*private loadAllUsers() {
        this.cardService.getAll().subscribe(users => { this.users = users; });
    }*/
    
}
interface Post{
     id: number;
     title: string;
     body: string;
 }