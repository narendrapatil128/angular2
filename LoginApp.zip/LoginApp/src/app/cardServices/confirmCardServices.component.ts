import { Component} from '@angular/core';



@Component({
    moduleId: module.id.toString(),
    
    templateUrl: 'confirmCardServices.component.html',
   
     
})

export class ConfirmCardServicesComponent  {
    
}
