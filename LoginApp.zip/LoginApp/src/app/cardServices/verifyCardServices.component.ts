import { Component} from '@angular/core';



@Component({
    moduleId: module.id.toString(),
    
    templateUrl: 'verifyCardServices.component.html',
   
     
})

export class VerifyCardServicesComponent  {
    
}
