import {Injectable, Pipe,PipeTransform} from '@angular/core';

@Pipe({
    name: 'myfilter',
     pure: false
})
@Injectable()
export class MyFilterPipe implements PipeTransform {
    transform(cards: any[], args: any[]): any {
        return cards.filter(cards => cards.userId.indexOf(args[0]) !== -1);
        
    }
}