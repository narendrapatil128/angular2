/**
 * @experimental Animation support is experimental.
 */
export declare class BrowserAnimationsModule {
}
/**
 * @experimental Animation support is experimental.
 */
export declare class NoopAnimationsModule {
}
