export function inc (value) {
    return value + 10;
}

export function dec (value) {
    return value - 10;
}
